<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content_area">
            <div class="main_content floatleft">
                <div class="col-md-12"><h1> <?php echo e($title); ?></h1></div>
            <div class="row">
                <div class="col-md-4"><img src="<?php echo e($imagelink); ?>"/> </div>

                <div class="col-md-8">
                    <span class="articletext"><?php echo e($shorttext); ?></span>
                </div>
            </div>

            </div>
               <?php echo $__env->make('newsletter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>