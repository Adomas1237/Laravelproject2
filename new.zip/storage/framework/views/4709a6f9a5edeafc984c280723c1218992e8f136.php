<?php header('Access-Control-Allow-Origin: *'); ?>
    <?php echo e($data); ?>

