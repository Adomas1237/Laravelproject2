<html>
<head>
    <title>insert</title>
</head>
<body>
<form action="/insert" method="post">
    <table>
        <tr>
            <?php echo csrf_field(); ?>
            <td>
                First name
            </td>
            <td><input type="text" name="firstName"></td>
        </tr>
        <tr>
            <td>
                last name
            </td>
            <td><input type="text" name="lastName"></td>
        </tr>
        <tr>
            <td>
                mobile
            </td>
            <td><input type="text" name="mobile"></td>
        <tr>

            <td><input type="submit" name="submit" value="Add"></td>
        </tr>
        </tr>
    </table>

</form>

</body>
</html>