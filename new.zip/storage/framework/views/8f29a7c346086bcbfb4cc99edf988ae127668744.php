<div class="sidebar floatright">
    <div class="single_sidebar"></div>


<?php echo Form::open(
array(
'route' => 'newsletter.store',
'class' => 'form')
); ?>

<div class="single_sidebar">
    <div class="news-letter">
        <h2>Sign Up for Newsletter</h2>
        <p>Sign up to receive our free newsletters!</p>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                There were some problems.<br /> <br/>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="flash-message">
            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Session::has('alert-' . $msg)): ?>

                    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <!-- end .flash-message -->
        <form action="#" method="post">
            <?php echo Form::label('Name'); ?>

            <?php echo Form::text('name', null,
              array(
                'class'=>'form-control',
                'placeholder'=>'List Name'
              )); ?>

            <?php echo Form::label('Email'); ?>

            <?php echo Form::text('email', null,
              array(
                'class'=>'form-control',
                'placeholder'=>'List Email'
              )); ?>


            <div class="form-group">
                <?php echo Form::submit('Submit!',
                  array('class'=>'btn btn-primary'
                )); ?>

            </div>
        </form>
        <p class="news-letter-privacy">We do not spam. We value your privacy!</p>
    </div>
</div>
<?php echo Form::close(); ?>