<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="content_area">
    <div class="main_content floatleft">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-md-4"><img src="<?php echo e($dat['imagelink']); ?>"/></div>
                <div class="col-md-8">
                    <a href="/post/<?php echo e($dat['id']); ?>">
                        <h2> <?php echo e($dat['title']); ?> </h2></a>

                <div>
                    <p><?php echo e($dat['shorttext']); ?></p></div>
            </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($data->links()); ?>


    </div>
<?php echo $__env->make('newsletter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>